class PublisherError(Exception):
    pass


class ConfigError(PublisherError):
    pass
