DEFAULT_CONFLUENCE_API_VERSION = '5.5.3'
DEFAULT_WATERMARK_CONTENT = 'Automatically generated content. Do not edit directly.'
